(function () {
  'use strict';

  var TAPPX_KEYS = [
    'pub-65263-android-0300',
    'pub-57747-android-0996',
    'pub-60567-android-4416',
    'pub-65262-android-8892',
    'pub-79956-android-6297',
    'pub-79955-android-5582'
  ];

  var STORAGE_KEY = 'alhikmah_tappx_index';

  function currentIndex() {
    var raw = parseInt(localStorage.getItem(STORAGE_KEY) || '0', 10);
    if (isNaN(raw) || raw < 0 || raw >= TAPPX_KEYS.length) return 0;
    return raw;
  }

  function advanceIndex() {
    var next = (currentIndex() + 1) % TAPPX_KEYS.length;
    localStorage.setItem(STORAGE_KEY, String(next));
    return next;
  }

  function nextKey() {
    var key = TAPPX_KEYS[currentIndex()];
    advanceIndex();
    return key;
  }

  function rotateAll() {
    var slots = document.querySelectorAll('[data-tappx-slot]');
    slots.forEach(function (slot) {
      var key = nextKey();
      slot.setAttribute('data-tappx-key', key);
      slot.textContent = 'Tappx Ad: ' + key;
    });
  }

  window.AlHikmahAds = {
    keys: TAPPX_KEYS.slice(),
    nextKey: nextKey,
    rotateAll: rotateAll
  };

  document.addEventListener('DOMContentLoaded', rotateAll);
  setInterval(rotateAll, 30000);
})();