const express = require("express");
const router = express.Router();

const TAPPX_KEYS = [
  "pub-65263-android-0300",
  "pub-57747-android-0996",
  "pub-60567-android-4416",
  "pub-65262-android-8892",
  "pub-79956-android-6297",
  "pub-79955-android-5582",
];

const CATEGORIES = [
  "Home", "Aplikasi", "Kisah Hikmah", "Kitab/Buku", "Pendidikan",
  "Sholawat", "Khutbah", "Kisah dan Tokoh", "Informasi", "Vidio",
  "Adhan", "Iqro'", "Tafsir Web", "Perpustakaan", "Arabic Pegon",
  "Arabic Calligraphy", "Kalender", "Timer", "Murotal 30 Juz",
  "Alqur'an Digital", "WebOffice", "CorelDRAW Arabic",
];

const QUICK_MENU = ["ADZKAR", "AL-QUR'AN", "TAKLIM", "HADIST", "SHOLAWAT", "ARABIC"];

const TOOLS = [
  { id: "arabic-pegon", name: "Konverter Arabic Pegon", category: "Arabic Pegon" },
  { id: "hijri-calendar", name: "Kalender Hijriah", category: "Kalender" },
  { id: "prayer-times", name: "Jadwal Adzan", category: "Adhan" },
  { id: "qibla", name: "Kompas Kiblat", category: "Adhan" },
  { id: "zakat", name: "Kalkulator Zakat", category: "Informasi" },
  { id: "murotal", name: "Murotal 30 Juz", category: "Murotal 30 Juz" },
  { id: "quran-digital", name: "Al-Qur'an Digital", category: "Alqur'an Digital" },
  { id: "calligraphy", name: "Arabic Calligraphy", category: "Arabic Calligraphy" },
  { id: "coreldraw-arabic", name: "CorelDRAW Arabic Assets", category: "CorelDRAW Arabic" },
  { id: "weboffice", name: "WebOffice", category: "WebOffice" },
];

let keyIndex = 0;

router.get("/health", (_req, res) => {
  res.json({ ok: true, service: "ALHIKMAH API", time: new Date().toISOString() });
});

router.get("/categories", (_req, res) => {
  res.json({ ok: true, total: CATEGORIES.length, categories: CATEGORIES, quickMenu: QUICK_MENU });
});

router.get("/tools", (_req, res) => {
  res.json({ ok: true, total: TOOLS.length, tools: TOOLS });
});

router.get("/articles", (req, res) => {
  const { category, q, limit } = req.query;
  const db = require("../data/articles.json");
  let items = Array.isArray(db) ? db : db.articles || [];
  if (category) items = items.filter((a) => a.category === category);
  if (q) {
    const needle = String(q).toLowerCase();
    items = items.filter(
      (a) =>
        a.title.toLowerCase().includes(needle) ||
        (a.excerpt || "").toLowerCase().includes(needle)
    );
  }
  const max = Number(limit) || items.length;
  res.json({ ok: true, total: items.length, articles: items.slice(0, max) });
});

router.get("/articles/:slug", (req, res) => {
  const db = require("../data/articles.json");
  const items = Array.isArray(db) ? db : db.articles || [];
  const found = items.find((a) => a.slug === req.params.slug);
  if (!found) return res.status(404).json({ ok: false, message: "Artikel tidak ditemukan" });
  res.json({ ok: true, article: found });
});

router.get("/ads/rotate", (_req, res) => {
  const key = TAPPX_KEYS[keyIndex % TAPPX_KEYS.length];
  keyIndex += 1;
  res.json({
    ok: true,
    provider: "tappx",
    appKey: key,
    pool: TAPPX_KEYS.length,
    servedAt: new Date().toISOString(),
  });
});

router.get("/ads/pool", (_req, res) => {
  res.json({ ok: true, provider: "tappx", keys: TAPPX_KEYS });
});

module.exports = router;