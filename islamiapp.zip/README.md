# ALHIKMAH

Portal Islam terpercaya untuk pendidikan, sejarah, sosial, dan budaya — [alhikmah.my.id](https://alhikmah.my.id).

## 🚀 Quick Navigation & Project Directory

Explore the live applications and directories hosted on our platform. Click **View Now** to check out each live section directly!

| No. | Project / Folder | Description | Live Link / Action |
| :---: | :--- | :--- | :---: |
| 1 | **Aplikasi** | Collection of custom interactive web applications and utilities. | [View Now](https://awdevmyid.github.io/aplikasi/) |
| 2 | **Calligraphy** | Arabic calligraphy and typography design tools and generators. | [View Now](https://awdevmyid.github.io/calligraphy/) |
| 3 | **Code** | Programming snippets, templates, and code resources. | [View Now](https://awdevmyid.github.io/code/) |
| 4 | **Collor** | Color palette generators, color picker, and design color tools. | [View Now](https://awdevmyid.github.io/collor/) |
| 5 | **EQ** | Equalizer and sound tuning parameters / audio utilities. | [View Now](https://awdevmyid.github.io/eq/) |
| 6 | **Finder** | Search utility and index finder tools for quick lookup. | [View Now](https://awdevmyid.github.io/finder/) |
| 7 | **Img** | Image gallery, logos, icons, and visual assets storage. | [View Now](https://awdevmyid.github.io/img/) |
| 8 | **Kodepost** | Indonesian postal code (Kode Pos) finder and regional lookup. | [View Now](https://awdevmyid.github.io/kodepost/) |
| 9 | **Maps** | Interactive map integrations, geolocation, and mapping tools. | [View Now](https://awdevmyid.github.io/maps/) |
| 10 | **QR** | QR Code generator and scanner web utility. | [View Now](https://awdevmyid.github.io/qr/) |
| 11 | **Quran** | Digital Al-Quran reader, search, and audio recitation web app. | [View Now](https://awdevmyid.github.io/quran/) |
| 12 | **SEO** | Search Engine Optimization analysis tools and meta tag generators. | [View Now](https://awdevmyid.github.io/seo/) |
| 13 | **Source** | Open-source code templates and repository resource files. | [View Now](https://awdevmyid.github.io/source/) |
| 14 | **Tools** | Multi-purpose utility web tools for daily productivity. | [View Now](https://awdevmyid.github.io/tools/) |
| 15 | **Vidio** | Video showcase, cinematic clips, and video streaming directory. | [View Now](https://awdevmyid.github.io/vidio/) |
