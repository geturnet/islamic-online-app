import type { Config, Context } from "@netlify/functions";
import { ARTICLES, CATEGORIES, NAV_MENU, TAPPX_KEYS } from "../../src/data/articles.ts";

const TOOLS = [
  { id: "arabic-pegon", name: "Konverter Arabic Pegon", category: "Arabic Pegon" },
  { id: "hijri-calendar", name: "Kalender Hijriah", category: "Kalender" },
  { id: "prayer-times", name: "Jadwal Adzan", category: "Adhan" },
  { id: "qibla", name: "Kompas Kiblat", category: "Adhan" },
  { id: "zakat", name: "Kalkulator Zakat", category: "Informasi" },
  { id: "murotal", name: "Murotal 30 Juz", category: "Murotal 30 Juz" },
  { id: "quran-digital", name: "Al-Qur'an Digital", category: "Alqur'an Digital" },
  { id: "calligraphy", name: "Arabic Calligraphy", category: "Arabic Calligraphy" },
  { id: "coreldraw-arabic", name: "CorelDRAW Arabic Assets", category: "CorelDRAW Arabic" },
  { id: "weboffice", name: "WebOffice", category: "WebOffice" },
];

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*" },
  });

export default async (req: Request, _context: Context) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api\/?/, "").replace(/\/$/, "");
  const [section, param] = path.split("/");

  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  switch (section) {
    case "health":
      return json({ ok: true, service: "ALHIKMAH API", time: new Date().toISOString() });

    case "categories":
      return json({ ok: true, total: CATEGORIES.length, categories: CATEGORIES, quickMenu: NAV_MENU });

    case "tools":
      return json({ ok: true, total: TOOLS.length, tools: TOOLS });

    case "articles": {
      if (param) {
        const found = ARTICLES.find((a) => a.slug === param);
        if (!found) return json({ ok: false, message: "Artikel tidak ditemukan" }, 404);
        return json({ ok: true, article: found });
      }
      const category = url.searchParams.get("category");
      const q = url.searchParams.get("q");
      const limit = Number(url.searchParams.get("limit"));
      let items = ARTICLES;
      if (category) items = items.filter((a) => a.category === category);
      if (q) {
        const needle = q.toLowerCase();
        items = items.filter(
          (a) => a.title.toLowerCase().includes(needle) || a.excerpt.toLowerCase().includes(needle)
        );
      }
      const max = limit > 0 ? limit : items.length;
      return json({ ok: true, total: items.length, articles: items.slice(0, max) });
    }

    case "ads": {
      if (param === "rotate") {
        // Stateless rotation: pick a key based on the current time slot.
        const idx = Math.floor(Date.now() / 1000) % TAPPX_KEYS.length;
        return json({
          ok: true,
          provider: "tappx",
          appKey: TAPPX_KEYS[idx],
          pool: TAPPX_KEYS.length,
          servedAt: new Date().toISOString(),
        });
      }
      if (param === "pool") return json({ ok: true, provider: "tappx", keys: TAPPX_KEYS });
      break;
    }
  }

  return json({ ok: false, message: "Not Found" }, 404);
};

export const config: Config = {
  path: ["/api", "/api/*"],
};
