import { Rocket, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { PROJECT_DIRECTORY } from "@/data/projects";

export function ProjectDirectory() {
  return (
    <Card id="project-directory" className="border-slate-200 bg-white shadow-sm overflow-hidden">
      <CardContent className="p-5 md:p-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center shadow-sm">
            <Rocket className="h-5 w-5 text-white" />
          </div>
          <h3 className="text-lg font-bold font-serif text-slate-900">🚀 Quick Navigation &amp; Project Directory</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          Explore the live applications and directories hosted on our platform. Click <strong>View Now</strong> to check out each live section directly!
        </p>

        {/* Tabel untuk layar lebar */}
        <div className="hidden sm:block overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-sm">
            <thead className="bg-emerald-50 text-emerald-900">
              <tr>
                <th className="px-3 py-2 text-center font-semibold w-12">No.</th>
                <th className="px-3 py-2 text-left font-semibold">Project / Folder</th>
                <th className="px-3 py-2 text-left font-semibold">Description</th>
                <th className="px-3 py-2 text-center font-semibold">Live Link / Action</th>
              </tr>
            </thead>
            <tbody>
              {PROJECT_DIRECTORY.map((p, i) => (
                <tr key={p.name} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-3 py-2 text-center text-slate-500">{i + 1}</td>
                  <td className="px-3 py-2 font-semibold text-slate-900">{p.name}</td>
                  <td className="px-3 py-2 text-slate-600">{p.description}</td>
                  <td className="px-3 py-2 text-center">
                    <a
                      href={p.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-3 py-1 text-xs font-medium text-white hover:bg-emerald-700 transition-colors whitespace-nowrap"
                    >
                      View Now <ExternalLink className="h-3 w-3" />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Daftar kartu untuk mobile */}
        <ul className="sm:hidden space-y-2">
          {PROJECT_DIRECTORY.map((p, i) => (
            <li key={p.name} className="rounded-lg border border-slate-200 p-3 flex items-start gap-3">
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 rounded-md h-6 w-6 flex items-center justify-center shrink-0">{i + 1}</span>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-900 text-sm">{p.name}</p>
                <p className="text-xs text-slate-600 mt-0.5">{p.description}</p>
              </div>
              <a
                href={p.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-2.5 py-1 text-xs font-medium text-white hover:bg-emerald-700 shrink-0"
              >
                View Now <ExternalLink className="h-3 w-3" />
              </a>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
