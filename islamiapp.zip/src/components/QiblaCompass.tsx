import { useEffect, useState } from "react";
import { Compass, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { distanceToKaaba, qiblaBearing, type GeoLocation } from "@/lib/islamic";

type OrientationEventIOS = DeviceOrientationEvent & { webkitCompassHeading?: number };
type DOEStatic = typeof DeviceOrientationEvent & { requestPermission?: () => Promise<"granted" | "denied"> };

/** Kompas kiblat: menghitung arah kiblat dari koordinat & membaca sensor orientasi perangkat. */
export function QiblaCompass({ loc, compact = false }: { loc: GeoLocation; compact?: boolean }) {
  const qibla = qiblaBearing(loc.lat, loc.lng);
  const [heading, setHeading] = useState<number | null>(null);
  const [active, setActive] = useState(false);

  useEffect(() => {
    if (!active) return;
    const handler = (e: Event) => {
      const ev = e as OrientationEventIOS;
      if (typeof ev.webkitCompassHeading === "number") setHeading(ev.webkitCompassHeading);
      else if (ev.alpha != null) setHeading((360 - ev.alpha) % 360);
    };
    const evt = "ondeviceorientationabsolute" in window ? "deviceorientationabsolute" : "deviceorientation";
    window.addEventListener(evt, handler);
    return () => window.removeEventListener(evt, handler);
  }, [active]);

  const enable = async () => {
    const DOE = (window as unknown as { DeviceOrientationEvent?: DOEStatic }).DeviceOrientationEvent;
    if (DOE?.requestPermission) {
      try { if ((await DOE.requestPermission()) !== "granted") return; } catch { return; }
    }
    setActive(true);
  };

  const dialRotation = heading == null ? 0 : -heading;
  const aligned = heading != null && Math.abs(((qibla - heading + 540) % 360) - 180) < 5;
  const size = compact ? "h-36 w-36" : "h-64 w-64";

  return (
    <Card className="border-teal-200 bg-gradient-to-br from-teal-50 to-emerald-50 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-teal-900 flex items-center gap-2">
          <Compass className="h-4 w-4 text-teal-600" /> Kompas Kiblat
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center py-3 gap-3">
        <div className={`relative ${size} rounded-full border-4 ${aligned ? "border-emerald-500" : "border-teal-200"} bg-white shadow-inner transition-colors`}>
          <div className="absolute inset-0 transition-transform duration-300" style={{ transform: `rotate(${dialRotation}deg)` }}>
            {["U", "T", "S", "B"].map((d, i) => (
              <span key={d} className={`absolute text-xs font-bold ${d === "U" ? "text-rose-600" : "text-slate-500"}`}
                style={{ left: "50%", top: "50%", transform: `rotate(${i * 90}deg) translateY(-${compact ? 56 : 112}px) rotate(-${i * 90}deg) translate(-50%, -50%)` }}>{d}</span>
            ))}
            <div className="absolute inset-0 flex items-start justify-center" style={{ transform: `rotate(${qibla}deg)` }}>
              <div className="flex flex-col items-center mt-3">
                <span className={compact ? "text-base" : "text-2xl"}>🕋</span>
                <Navigation className={`${compact ? "h-5 w-5" : "h-8 w-8"} text-emerald-600 fill-emerald-600`} />
              </div>
            </div>
          </div>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <p className={`${compact ? "text-xl" : "text-3xl"} font-bold text-teal-900`}>{qibla.toFixed(1)}°</p>
            <p className="text-[10px] text-teal-600 uppercase tracking-wider">dari Utara</p>
          </div>
        </div>
        <p className="text-xs text-teal-700 text-center">
          {loc.label} · {Math.round(distanceToKaaba(loc.lat, loc.lng)).toLocaleString("id-ID")} km ke Ka'bah
        </p>
        {heading == null ? (
          <Button size="sm" onClick={enable} className="bg-teal-600 hover:bg-teal-700 text-white">
            {active ? "Menunggu sensor kompas..." : "Aktifkan Sensor Kompas"}
          </Button>
        ) : (
          <p className={`text-xs font-semibold ${aligned ? "text-emerald-700" : "text-slate-600"}`}>
            {aligned ? "✓ Anda menghadap kiblat" : `Arah perangkat ${Math.round(heading)}° — putar hingga 🕋 di atas`}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
