import { useState } from "react";
import { Download, FileImage, Palette, FileCode2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { downloadFile } from "@/lib/islamic";
import { CALLIGRAPHY_FONTS, PRESET_TEXTS, buildSVG, renderCalligraphyPNG } from "@/lib/calligraphy";
import { PageHeader, inputClass, CategoryArticles } from "./_shared";

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-");

export default function CorelDrawPage() {
  const [font, setFont] = useState("Amiri");
  const [color, setColor] = useState("#065f46");
  const [custom, setCustom] = useState("");

  const assetSVG = (text: string, name: string) =>
    downloadFile(`${slug(name)}-${slug(font)}.svg`, buildSVG({ text, font, color, bg: "#ffffff", size: 140, transparent: true }), "image/svg+xml");

  const assetPNG = async (text: string, name: string) => {
    const url = await renderCalligraphyPNG({ text, font, color, bg: "#ffffff", size: 90, width: 2400, height: 1000, transparent: true });
    const a = document.createElement("a");
    a.href = url;
    a.download = `${slug(name)}-${slug(font)}.png`;
    a.click();
  };

  return (
    <div className="space-y-5">
      <PageHeader icon={Palette} title="CorelDRAW Arabic" desc="Aset teks Arab siap impor ke CorelDRAW / Illustrator (SVG vektor & PNG transparan)" />

      <Card className="border-emerald-200">
        <CardContent className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
          <div>
            <label className="text-xs font-medium text-slate-600 mb-1 block">Font</label>
            <select value={font} onChange={(e) => setFont(e.target.value)} className={inputClass}>
              {CALLIGRAPHY_FONTS.map((f) => <option key={f.id} value={f.id}>{f.style} — {f.id}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-600 mb-1 block">Warna</label>
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-10 w-full rounded-lg border border-emerald-200" />
          </div>
          <p className="text-[11px] text-slate-500">Tip: untuk SVG, pasang font "{font}" dari Google Fonts lalu di CorelDRAW gunakan <b>Convert to Curves</b> (Ctrl+Q).</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {PRESET_TEXTS.map((t) => (
          <Card key={t.latin} className="border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all">
            <CardContent className="p-3 text-center">
              <p className="text-2xl min-h-16 flex items-center justify-center" dir="rtl" style={{ fontFamily: `"${font}", Amiri, serif`, color }}>{t.ar}</p>
              <p className="text-xs text-slate-500 mb-2">{t.latin}</p>
              <div className="grid grid-cols-2 gap-1">
                <Button size="sm" variant="outline" onClick={() => assetSVG(t.ar, t.latin)} className="h-7 text-[11px] border-emerald-300 text-emerald-700 px-1"><FileCode2 className="h-3 w-3 mr-0.5" />SVG</Button>
                <Button size="sm" variant="outline" onClick={() => assetPNG(t.ar, t.latin)} className="h-7 text-[11px] border-emerald-300 text-emerald-700 px-1"><FileImage className="h-3 w-3 mr-0.5" />PNG</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-emerald-200">
        <CardHeader className="pb-2"><CardTitle className="text-sm">Buat Aset Teks Arab Sendiri</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <textarea value={custom} onChange={(e) => setCustom(e.target.value)} rows={2} dir="rtl" placeholder="اكتب النص العربي..." className={cn(inputClass, "text-2xl font-serif text-right")} />
          <div className="flex gap-2">
            <Button disabled={!custom} onClick={() => assetSVG(custom, "custom")} className="bg-emerald-600 hover:bg-emerald-700 text-white"><Download className="h-4 w-4 mr-1" /> Unduh SVG</Button>
            <Button disabled={!custom} variant="outline" onClick={() => assetPNG(custom, "custom")} className="border-emerald-300 text-emerald-700"><Download className="h-4 w-4 mr-1" /> Unduh PNG</Button>
          </div>
        </CardContent>
      </Card>
      <CategoryArticles category="CorelDRAW Arabic" />
    </div>
  );
}
