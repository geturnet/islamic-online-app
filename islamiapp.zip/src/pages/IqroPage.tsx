import { useState } from "react";
import { GraduationCap, Volume2, ChevronLeft, ChevronRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { speakArabic } from "@/lib/islamic";
import { PageHeader, CategoryArticles } from "./_shared";

const HIJAIYAH = [
  ["ا", "Alif"], ["ب", "Ba"], ["ت", "Ta"], ["ث", "Tsa"], ["ج", "Jim"], ["ح", "Ha"], ["خ", "Kho"],
  ["د", "Dal"], ["ذ", "Dzal"], ["ر", "Ro"], ["ز", "Za"], ["س", "Sin"], ["ش", "Syin"], ["ص", "Shod"],
  ["ض", "Dhod"], ["ط", "Tho"], ["ظ", "Zho"], ["ع", "'Ain"], ["غ", "Ghoin"], ["ف", "Fa"], ["ق", "Qof"],
  ["ك", "Kaf"], ["ل", "Lam"], ["م", "Mim"], ["ن", "Nun"], ["و", "Wau"], ["ه", "Ha"], ["ء", "Hamzah"], ["ي", "Ya"],
] as const;

const LATIN_BASE: Record<string, string> = {
  "ا": "a", "ب": "b", "ت": "t", "ث": "ts", "ج": "j", "ح": "h", "خ": "kh", "د": "d", "ذ": "dz", "ر": "r", "ز": "z",
  "س": "s", "ش": "sy", "ص": "sh", "ض": "dh", "ط": "th", "ظ": "zh", "ع": "'", "غ": "gh", "ف": "f", "ق": "q",
  "ك": "k", "ل": "l", "م": "m", "ن": "n", "و": "w", "ه": "h", "ء": "'", "ي": "y",
};

type Item = { ar: string; latin: string };
const withHarakat = (h: string, v: string): Item[] =>
  HIJAIYAH.filter(([c]) => c !== "ء").map(([c]) => ({
    ar: (c === "ا" ? "أ" : c) + h,
    latin: (c === "ا" ? "" : LATIN_BASE[c]) + v,
  }));

const LEVELS: { level: number; title: string; desc: string; items: Item[] }[] = [
  { level: 1, title: "Huruf Hijaiyah", desc: "Mengenal 29 huruf hijaiyah tunggal", items: HIJAIYAH.map(([ar, latin]) => ({ ar, latin })) },
  { level: 2, title: "Fathah (a)", desc: "Huruf berharakat fathah", items: withHarakat("َ", "a") },
  { level: 3, title: "Kasrah (i)", desc: "Huruf berharakat kasrah", items: withHarakat("ِ", "i") },
  { level: 4, title: "Dhommah (u)", desc: "Huruf berharakat dhommah", items: withHarakat("ُ", "u") },
  { level: 5, title: "Tanwin", desc: "Fathatain, kasratain, dhommatain", items: [...withHarakat("ً", "an").slice(0, 10), ...withHarakat("ٍ", "in").slice(0, 10), ...withHarakat("ٌ", "un").slice(0, 8)] },
  {
    level: 6, title: "Sukun, Tasydid & Mad", desc: "Bacaan sukun, tasydid dan panjang (mad)",
    items: [
      { ar: "اَبْ", latin: "ab" }, { ar: "اِتْ", latin: "it" }, { ar: "اُمْ", latin: "um" }, { ar: "مِنْ", latin: "min" },
      { ar: "قُلْ", latin: "qul" }, { ar: "رَبَّ", latin: "rabba" }, { ar: "اِنَّ", latin: "inna" }, { ar: "ثُمَّ", latin: "tsumma" },
      { ar: "بَا", latin: "baa" }, { ar: "قِيْ", latin: "qii" }, { ar: "نُوْ", latin: "nuu" }, { ar: "مَالِكِ", latin: "maaliki" },
      { ar: "اَلْحَمْدُ", latin: "al-hamdu" }, { ar: "رَحِيْمِ", latin: "rahiimi" }, { ar: "نَسْتَعِيْنُ", latin: "nasta'iinu" }, { ar: "صِرَاطَ", latin: "shiraatha" },
    ],
  },
];

const PROGRESS_KEY = "alhikmah:iqro-progress";

export default function IqroPage() {
  const [level, setLevel] = useState(1);
  const [active, setActive] = useState<number | null>(null);
  const [mode, setMode] = useState<"belajar" | "kuis">("belajar");
  const [quiz, setQuiz] = useState(() => ({ idx: 0, score: 0, answered: null as string | null }));
  const [done, setDone] = useState<number[]>(() => { try { return JSON.parse(localStorage.getItem(PROGRESS_KEY) || "[]"); } catch { return []; } });
  const [noTts, setNoTts] = useState(false);
  const lv = LEVELS[level - 1];

  const say = (it: Item, i: number) => { setActive(i); if (!speakArabic(it.ar)) setNoTts(true); };
  const markDone = () => {
    const next = Array.from(new Set([...done, level]));
    setDone(next);
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(next));
  };

  const q = lv.items[quiz.idx % lv.items.length];
  const options = (() => {
    const pool = lv.items.filter((x) => x.latin !== q.latin);
    const seed = quiz.idx * 7 + level;
    const picks = [pool[seed % pool.length], pool[(seed * 3 + 1) % pool.length], pool[(seed * 5 + 2) % pool.length]].map((x) => x.latin);
    const all = Array.from(new Set([q.latin, ...picks])).slice(0, 4);
    return all.sort((a, b) => ((a.charCodeAt(0) * seed) % 7) - ((b.charCodeAt(0) * seed) % 7));
  })();

  return (
    <div className="space-y-5">
      <PageHeader icon={GraduationCap} title="Iqro' Digital" desc="Belajar membaca Al-Qur'an jilid 1–6 dengan suara & kuis interaktif" />
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {LEVELS.map((l) => (
          <button key={l.level} onClick={() => { setLevel(l.level); setActive(null); setQuiz({ idx: 0, score: 0, answered: null }); }}
            className={cn("rounded-xl border p-3 text-center transition-all relative", level === l.level ? "bg-emerald-600 text-white border-emerald-600 shadow" : "bg-white border-emerald-200 hover:bg-emerald-50")}>
            {done.includes(l.level) && <CheckCircle2 className="h-4 w-4 absolute top-1 right-1 text-amber-400" />}
            <p className="text-xl font-bold">{l.level}</p>
            <p className="text-[10px] leading-tight">{l.title}</p>
          </button>
        ))}
      </div>

      <Card className="border-emerald-200">
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="font-bold text-slate-900">Iqro' {lv.level} — {lv.title}</h3>
              <p className="text-xs text-slate-500">{lv.desc} · ketuk huruf untuk mendengar</p>
            </div>
            <div className="flex gap-1 bg-slate-100 p-1 rounded-lg">
              {(["belajar", "kuis"] as const).map((m) => (
                <button key={m} onClick={() => setMode(m)} className={cn("px-3 py-1 rounded-md text-xs font-medium capitalize", mode === m ? "bg-emerald-600 text-white" : "text-slate-600")}>{m}</button>
              ))}
            </div>
          </div>
          {noTts && <p className="text-xs text-amber-700 bg-amber-50 rounded p-2">Browser Anda belum mendukung suara bahasa Arab. Gunakan Chrome/Edge versi terbaru.</p>}

          {mode === "belajar" ? (
            <>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2" dir="rtl">
                {lv.items.map((it, i) => (
                  <button key={i} onClick={() => say(it, i)}
                    className={cn("aspect-square rounded-xl border flex flex-col items-center justify-center transition-all active:scale-95", active === i ? "bg-emerald-600 text-white border-emerald-600 shadow-md" : "bg-white border-emerald-200 hover:bg-emerald-50")}>
                    <span className="text-3xl font-serif leading-none">{it.ar}</span>
                    <span className={cn("text-[10px] mt-1", active === i ? "text-emerald-100" : "text-slate-500")} dir="ltr">{it.latin}</span>
                  </button>
                ))}
              </div>
              <div className="flex justify-between">
                <Button size="sm" variant="outline" disabled={level === 1} onClick={() => setLevel(level - 1)} className="border-emerald-300 text-emerald-700"><ChevronLeft className="h-4 w-4 mr-1" /> Jilid sebelumnya</Button>
                <Button size="sm" onClick={() => { markDone(); if (level < 6) setLevel(level + 1); }} className="bg-emerald-600 hover:bg-emerald-700 text-white">Tandai selesai <ChevronRight className="h-4 w-4 ml-1" /></Button>
              </div>
            </>
          ) : (
            <div className="text-center space-y-4 py-2">
              <p className="text-xs text-slate-500">Soal {quiz.idx + 1} · Skor {quiz.score}</p>
              <button onClick={() => speakArabic(q.ar)} className="mx-auto h-28 w-28 rounded-2xl bg-emerald-50 border-2 border-emerald-300 flex items-center justify-center">
                <span className="text-6xl font-serif">{q.ar}</span>
              </button>
              <p className="text-sm text-slate-600 flex items-center justify-center gap-1"><Volume2 className="h-4 w-4" /> Bagaimana cara membacanya?</p>
              <div className="grid grid-cols-2 gap-2 max-w-sm mx-auto">
                {options.map((o) => (
                  <button key={o} disabled={!!quiz.answered}
                    onClick={() => setQuiz((s) => ({ ...s, answered: o, score: s.score + (o === q.latin ? 1 : 0) }))}
                    className={cn("rounded-lg border py-2.5 font-semibold transition-colors",
                      quiz.answered ? (o === q.latin ? "bg-emerald-600 text-white border-emerald-600" : o === quiz.answered ? "bg-rose-100 border-rose-300 text-rose-700" : "bg-white border-slate-200") : "bg-white border-emerald-200 hover:bg-emerald-50")}>
                    {o}
                  </button>
                ))}
              </div>
              {quiz.answered && (
                <Button onClick={() => setQuiz((s) => ({ idx: s.idx + 1, score: s.score, answered: null }))} className="bg-emerald-600 hover:bg-emerald-700 text-white">Soal berikutnya</Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      <CategoryArticles category="Iqro'" />
    </div>
  );
}
