import { useEffect, useRef, useState } from "react";
import { Bold, Italic, Underline, List, ListOrdered, AlignLeft, AlignCenter, AlignRight, Heading1, Heading2, Printer, FileDown, FilePlus2, Save, Undo2, Redo2, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { downloadFile } from "@/lib/islamic";
import { PageHeader, CategoryArticles } from "./_shared";

const DOCS_KEY = "alhikmah:weboffice-docs";
type Doc = { id: string; title: string; html: string; updated: number };

const TEMPLATES: { name: string; html: string }[] = [
  { name: "Dokumen Kosong", html: "<p></p>" },
  { name: "Surat Undangan Pengajian", html: "<h1 style='text-align:center'>UNDANGAN PENGAJIAN</h1><p>Assalamu'alaikum Wr. Wb.</p><p>Dengan hormat, kami mengundang Bapak/Ibu/Saudara untuk menghadiri pengajian rutin yang insyaAllah akan dilaksanakan pada:</p><ul><li>Hari/Tanggal: ...</li><li>Waktu: ...</li><li>Tempat: ...</li></ul><p>Atas perhatian dan kehadirannya kami ucapkan jazakumullah khairan katsiran.</p><p>Wassalamu'alaikum Wr. Wb.</p>" },
  { name: "Notulen Rapat Takmir", html: "<h1>NOTULEN RAPAT TAKMIR MASJID</h1><p><b>Tanggal:</b> ...<br><b>Peserta:</b> ...</p><h2>Agenda</h2><ol><li>...</li></ol><h2>Keputusan</h2><ol><li>...</li></ol>" },
  { name: "Laporan Kas Masjid", html: "<h1 style='text-align:center'>LAPORAN KAS MASJID</h1><table border='1' style='width:100%;border-collapse:collapse'><tr><th>Tanggal</th><th>Keterangan</th><th>Masuk</th><th>Keluar</th></tr><tr><td>...</td><td>...</td><td>...</td><td>...</td></tr></table>" },
];

const loadDocs = (): Doc[] => { try { return JSON.parse(localStorage.getItem(DOCS_KEY) || "[]"); } catch { return []; } };

export default function WebOfficePage() {
  const [docs, setDocs] = useState<Doc[]>(loadDocs);
  const [current, setCurrent] = useState<Doc>(() => loadDocs()[0] ?? { id: crypto.randomUUID(), title: "Dokumen Tanpa Judul", html: TEMPLATES[0].html, updated: Date.now() });
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const editorRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (editorRef.current) editorRef.current.innerHTML = current.html; }, [current.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const persist = (list: Doc[]) => { setDocs(list); localStorage.setItem(DOCS_KEY, JSON.stringify(list)); };

  const save = () => {
    const html = editorRef.current?.innerHTML ?? "";
    const doc = { ...current, html, updated: Date.now() };
    setCurrent(doc);
    persist([doc, ...docs.filter((d) => d.id !== doc.id)]);
    setSavedAt(Date.now());
  };

  // Simpan otomatis setiap 10 detik
  useEffect(() => { const t = setInterval(save, 10000); return () => clearInterval(t); }); // eslint-disable-line react-hooks/exhaustive-deps

  const exec = (cmd: string, value?: string) => { document.execCommand(cmd, false, value); editorRef.current?.focus(); };
  const newDoc = (tpl = TEMPLATES[0]) => { save(); setCurrent({ id: crypto.randomUUID(), title: tpl.name === "Dokumen Kosong" ? "Dokumen Tanpa Judul" : tpl.name, html: tpl.html, updated: Date.now() }); };
  const remove = (id: string) => {
    persist(docs.filter((d) => d.id !== id));
    if (id === current.id) setCurrent({ id: crypto.randomUUID(), title: "Dokumen Tanpa Judul", html: TEMPLATES[0].html, updated: Date.now() });
  };

  const html = () => editorRef.current?.innerHTML ?? "";
  const exportDoc = () => downloadFile(`${current.title}.doc`, `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>${current.title}</title></head><body>${html()}</body></html>`, "application/msword");
  const exportHtml = () => downloadFile(`${current.title}.html`, `<!doctype html><html><head><meta charset="utf-8"><title>${current.title}</title></head><body>${html()}</body></html>`, "text/html");
  const exportTxt = () => downloadFile(`${current.title}.txt`, editorRef.current?.innerText ?? "");
  const print = () => {
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(`<html><head><title>${current.title}</title><style>body{font-family:serif;padding:40px;line-height:1.6}table{border-collapse:collapse}td,th{border:1px solid #333;padding:4px 8px}</style></head><body>${html()}</body></html>`);
    w.document.close();
    w.focus();
    w.print();
  };

  const tools: [React.ComponentType<{ className?: string }>, string, () => void][] = [
    [Undo2, "Undo", () => exec("undo")], [Redo2, "Redo", () => exec("redo")],
    [Heading1, "Judul", () => exec("formatBlock", "<h1>")], [Heading2, "Subjudul", () => exec("formatBlock", "<h2>")],
    [Bold, "Tebal", () => exec("bold")], [Italic, "Miring", () => exec("italic")], [Underline, "Garis bawah", () => exec("underline")],
    [List, "Daftar", () => exec("insertUnorderedList")], [ListOrdered, "Daftar bernomor", () => exec("insertOrderedList")],
    [AlignLeft, "Rata kiri", () => exec("justifyLeft")], [AlignCenter, "Tengah", () => exec("justifyCenter")], [AlignRight, "Rata kanan", () => exec("justifyRight")],
  ];

  return (
    <div className="space-y-5">
      <PageHeader icon={Layers} title="WebOffice" desc="Editor dokumen online — tulis, simpan otomatis di perangkat, ekspor ke Word/HTML/TXT & cetak" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <Card className="border-slate-200 lg:col-span-1 order-2 lg:order-1">
          <CardContent className="p-3 space-y-3">
            <div>
              <p className="text-xs font-semibold text-slate-700 mb-1.5">Template baru</p>
              {TEMPLATES.map((t) => (
                <button key={t.name} onClick={() => newDoc(t)} className="w-full text-left text-xs px-2 py-1.5 rounded hover:bg-emerald-50 text-emerald-800 flex items-center gap-1.5"><FilePlus2 className="h-3.5 w-3.5" /> {t.name}</button>
              ))}
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-700 mb-1.5">Dokumen saya ({docs.length})</p>
              {docs.length === 0 && <p className="text-xs text-slate-400">Belum ada dokumen tersimpan.</p>}
              {docs.map((d) => (
                <div key={d.id} className={cn("flex items-center gap-1 rounded px-2 py-1.5 text-xs", d.id === current.id ? "bg-emerald-100" : "hover:bg-slate-50")}>
                  <button onClick={() => { save(); setCurrent(d); }} className="flex-1 text-left truncate">{d.title}</button>
                  <button onClick={() => remove(d.id)} className="text-rose-500 hover:text-rose-700" title="Hapus">×</button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-200 lg:col-span-3 order-1 lg:order-2 overflow-hidden">
          <div className="border-b border-emerald-100 bg-emerald-50/60 p-2 space-y-2">
            <input value={current.title} onChange={(e) => setCurrent({ ...current, title: e.target.value })} className="w-full bg-transparent font-semibold text-slate-800 px-1 focus:outline-none" />
            <div className="flex flex-wrap gap-1">
              {tools.map(([Icon, label, fn]) => (
                <button key={label} title={label} onMouseDown={(e) => e.preventDefault()} onClick={fn} className="h-8 w-8 rounded hover:bg-white flex items-center justify-center text-slate-700"><Icon className="h-4 w-4" /></button>
              ))}
              <select onChange={(e) => exec("fontName", e.target.value)} defaultValue="" className="h-8 text-xs rounded border border-slate-200 bg-white">
                <option value="" disabled>Font</option>
                {["Georgia", "Arial", "Times New Roman", "Amiri", "Courier New"].map((f) => <option key={f}>{f}</option>)}
              </select>
              <input type="color" title="Warna teks" onChange={(e) => exec("foreColor", e.target.value)} className="h-8 w-8" />
            </div>
          </div>
          <div ref={editorRef} contentEditable suppressContentEditableWarning
            className="min-h-[28rem] p-6 prose prose-sm max-w-none focus:outline-none [&_h1]:text-2xl [&_h1]:font-bold [&_h2]:text-xl [&_h2]:font-semibold [&_ul]:list-disc [&_ul]:pl-6 [&_ol]:list-decimal [&_ol]:pl-6 [&_td]:border [&_td]:p-1 [&_th]:border [&_th]:p-1" />
          <div className="border-t border-emerald-100 p-2 flex flex-wrap items-center gap-2">
            <Button size="sm" onClick={save} className="bg-emerald-600 hover:bg-emerald-700 text-white"><Save className="h-4 w-4 mr-1" /> Simpan</Button>
            <Button size="sm" variant="outline" onClick={exportDoc} className="border-emerald-300 text-emerald-700"><FileDown className="h-4 w-4 mr-1" /> Word (.doc)</Button>
            <Button size="sm" variant="outline" onClick={exportHtml} className="border-emerald-300 text-emerald-700">HTML</Button>
            <Button size="sm" variant="outline" onClick={exportTxt} className="border-emerald-300 text-emerald-700">TXT</Button>
            <Button size="sm" variant="outline" onClick={print} className="border-emerald-300 text-emerald-700"><Printer className="h-4 w-4 mr-1" /> Cetak / PDF</Button>
            {savedAt && <span className="text-xs text-slate-400 ml-auto">Tersimpan {new Date(savedAt).toLocaleTimeString("id-ID")}</span>}
          </div>
        </Card>
      </div>
      <CategoryArticles category="WebOffice" />
    </div>
  );
}
