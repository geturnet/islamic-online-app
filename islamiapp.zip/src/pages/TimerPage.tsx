import { useEffect, useRef, useState } from "react";
import { Flag, Pause, Play, RotateCcw, Timer as TimerIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { beep } from "@/lib/islamic";
import { PageHeader, CategoryArticles } from "./_shared";

const PRESETS = [
  { label: "Dzikir pagi", s: 600 },
  { label: "Tilawah", s: 900 },
  { label: "Murajaah", s: 1200 },
  { label: "Kajian", s: 2700 },
  { label: "1 menit", s: 60 },
  { label: "5 menit", s: 300 },
];

const fmt = (ms: number) => {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600), m = Math.floor((total % 3600) / 60), s = total % 60;
  const cs = Math.floor((ms % 1000) / 10);
  return { main: `${h ? `${String(h).padStart(2, "0")}:` : ""}${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`, cs: String(cs).padStart(2, "0") };
};

export default function TimerPage() {
  const [mode, setMode] = useState<"timer" | "stopwatch">("timer");
  const [duration, setDuration] = useState(300_000);
  const [remaining, setRemaining] = useState(300_000);
  const [elapsed, setElapsed] = useState(0);
  const [running, setRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);
  const [customMin, setCustomMin] = useState("5");
  const [done, setDone] = useState(false);
  const startRef = useRef(0);
  const baseRef = useRef(0);

  useEffect(() => {
    if (!running) return;
    startRef.current = performance.now();
    baseRef.current = mode === "timer" ? remaining : elapsed;
    const id = setInterval(() => {
      const delta = performance.now() - startRef.current;
      if (mode === "timer") {
        const left = baseRef.current - delta;
        if (left <= 0) {
          setRemaining(0);
          setRunning(false);
          setDone(true);
          beep(0.4); setTimeout(() => beep(0.4), 500); setTimeout(() => beep(0.8, 660), 1000);
          if ("vibrate" in navigator) navigator.vibrate([300, 150, 300]);
        } else setRemaining(left);
      } else setElapsed(baseRef.current + delta);
    }, 50);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, mode]);

  useEffect(() => {
    const t = fmt(mode === "timer" ? remaining : elapsed).main;
    document.title = running ? `${t} · Timer | ALHIKMAH` : "Timer | ALHIKMAH";
  }, [remaining, elapsed, running, mode]);

  const setPreset = (s: number) => { setRunning(false); setDuration(s * 1000); setRemaining(s * 1000); setDone(false); };
  const reset = () => { setRunning(false); setDone(false); if (mode === "timer") setRemaining(duration); else { setElapsed(0); setLaps([]); } };
  const value = fmt(mode === "timer" ? remaining : elapsed);
  const progress = mode === "timer" ? 1 - remaining / duration : (elapsed % 60000) / 60000;

  return (
    <div className="space-y-5">
      <PageHeader icon={TimerIcon} title="Timer & Stopwatch" desc="Timer ibadah dengan alarm suara, stopwatch dengan catatan putaran" />
      <Card className="border-emerald-200">
        <CardContent className="p-6 flex flex-col items-center">
          <div className="flex gap-1 mb-6 bg-slate-100 p-1 rounded-xl">
            {(["timer", "stopwatch"] as const).map((m) => (
              <button key={m} onClick={() => { setRunning(false); setMode(m); }} className={cn("px-5 py-1.5 rounded-lg text-sm font-medium capitalize transition-all", mode === m ? "bg-emerald-600 text-white shadow-sm" : "text-slate-600")}>{m}</button>
            ))}
          </div>

          <div className="relative h-60 w-60">
            <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
              <circle cx="50" cy="50" r="45" fill="none" stroke="#d1fae5" strokeWidth="6" />
              <circle cx="50" cy="50" r="45" fill="none" stroke={done ? "#f59e0b" : "#059669"} strokeWidth="6" strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 45} strokeDashoffset={2 * Math.PI * 45 * (1 - progress)} className="transition-[stroke-dashoffset] duration-100" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="text-5xl font-bold tabular-nums text-emerald-900 font-serif">{value.main}</p>
              {mode === "stopwatch" && <p className="text-lg tabular-nums text-emerald-600">.{value.cs}</p>}
              {done && <p className="text-sm font-semibold text-amber-600 mt-1">Waktu habis!</p>}
            </div>
          </div>

          <div className="flex gap-2 mt-6">
            <Button onClick={() => { setDone(false); if (mode === "timer" && remaining <= 0) setRemaining(duration); setRunning((r) => !r); }} className="bg-emerald-600 hover:bg-emerald-700 text-white min-w-28">
              {running ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}{running ? "Jeda" : "Mulai"}
            </Button>
            <Button variant="outline" onClick={reset} className="border-emerald-300 text-emerald-700"><RotateCcw className="h-4 w-4 mr-2" />Reset</Button>
            {mode === "stopwatch" && (
              <Button variant="outline" disabled={!running} onClick={() => setLaps((l) => [elapsed, ...l])} className="border-emerald-300 text-emerald-700"><Flag className="h-4 w-4 mr-2" />Putaran</Button>
            )}
          </div>

          {mode === "timer" && (
            <div className="w-full mt-6 space-y-3">
              <div className="flex flex-wrap justify-center gap-2">
                {PRESETS.map((p) => (
                  <button key={p.label} onClick={() => setPreset(p.s)} className={cn("text-xs px-3 py-1.5 rounded-full border transition-colors", duration === p.s * 1000 ? "bg-emerald-600 text-white border-emerald-600" : "border-emerald-200 text-emerald-700 hover:bg-emerald-50")}>
                    {p.label} · {p.s / 60}m
                  </button>
                ))}
              </div>
              <div className="flex justify-center items-center gap-2">
                <input type="number" min={1} max={600} value={customMin} onChange={(e) => setCustomMin(e.target.value)} className="w-20 h-9 rounded-md border border-emerald-200 text-center text-sm" />
                <span className="text-sm text-slate-500">menit</span>
                <Button size="sm" variant="outline" onClick={() => Number(customMin) > 0 && setPreset(Number(customMin) * 60)} className="border-emerald-300 text-emerald-700">Atur</Button>
              </div>
            </div>
          )}

          {mode === "stopwatch" && laps.length > 0 && (
            <div className="w-full mt-6 max-h-48 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-lg">
              {laps.map((l, i) => (
                <div key={i} className="flex justify-between px-3 py-1.5 text-sm tabular-nums">
                  <span className="text-slate-500">Putaran {laps.length - i}</span>
                  <span className="font-semibold">{fmt(l).main}.{fmt(l).cs}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <CategoryArticles category="Timer" />
    </div>
  );
}
