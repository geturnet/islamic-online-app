import { useMemo, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight, ArrowRightLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { DAY_NAMES, HIJRI_MONTHS, ISLAMIC_EVENTS, MASEHI_MONTHS, toHijri } from "@/lib/islamic";
import { PageHeader, inputClass, CategoryArticles } from "./_shared";

export default function KalenderPage() {
  const today = new Date();
  const [month, setMonth] = useState(today.getMonth());
  const [year, setYear] = useState(today.getFullYear());
  const [offset, setOffset] = useState(0);
  const [picked, setPicked] = useState<Date>(today);
  const [convertInput, setConvertInput] = useState(today.toISOString().slice(0, 10));

  const cells = useMemo(() => {
    const first = new Date(year, month, 1).getDay();
    const days = new Date(year, month + 1, 0).getDate();
    const arr: (Date | null)[] = Array(first).fill(null);
    for (let d = 1; d <= days; d++) arr.push(new Date(year, month, d));
    return arr;
  }, [month, year]);

  const hStart = toHijri(new Date(year, month, 1), offset);
  const hEnd = toHijri(new Date(year, month + 1, 0), offset);
  const monthEvents = cells
    .filter((d): d is Date => !!d)
    .map((d) => ({ d, h: toHijri(d, offset) }))
    .filter(({ h }) => ISLAMIC_EVENTS[`${h.month}-${h.day}`]);

  const shift = (n: number) => {
    const d = new Date(year, month + n, 1);
    setMonth(d.getMonth());
    setYear(d.getFullYear());
  };

  const pickedH = toHijri(picked, offset);
  const conv = convertInput ? toHijri(new Date(convertInput + "T12:00:00"), offset) : null;

  return (
    <div className="space-y-5">
      <PageHeader icon={CalendarDays} title="Kalender Hijriyah & Masehi" desc="Penanggalan Islam (Umm al-Qura), hari besar Islam & konverter tanggal" />

      <Card className="border-emerald-200">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <Button size="icon" variant="outline" onClick={() => shift(-1)} className="border-emerald-300 text-emerald-700"><ChevronLeft className="h-4 w-4" /></Button>
            <div className="text-center">
              <p className="font-bold text-slate-800 text-lg">{MASEHI_MONTHS[month]} {year}</p>
              <p className="text-xs text-emerald-700">
                {hStart.monthName}{hStart.month !== hEnd.month ? ` – ${hEnd.monthName}` : ""} {hEnd.year} H
              </p>
            </div>
            <Button size="icon" variant="outline" onClick={() => shift(1)} className="border-emerald-300 text-emerald-700"><ChevronRight className="h-4 w-4" /></Button>
          </div>
          <div className="flex justify-center gap-2 mt-2">
            <Button size="sm" variant="ghost" className="text-xs text-emerald-700 h-7" onClick={() => { setMonth(today.getMonth()); setYear(today.getFullYear()); setPicked(today); }}>Hari ini</Button>
            <label className="text-xs text-slate-500 flex items-center gap-1">Koreksi rukyat
              <select value={offset} onChange={(e) => setOffset(Number(e.target.value))} className="h-7 rounded border border-emerald-200 text-xs">
                {[-2, -1, 0, 1, 2].map((o) => <option key={o} value={o}>{o > 0 ? `+${o}` : o} hari</option>)}
              </select>
            </label>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-7 gap-1 mb-1">
            {DAY_NAMES.map((d) => <div key={d} className={cn("text-center text-xs font-semibold py-1", d === "Jum'at" ? "text-emerald-700" : "text-slate-500")}>{d.slice(0, 3)}</div>)}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((d, i) => {
              if (!d) return <div key={i} />;
              const h = toHijri(d, offset);
              const ev = ISLAMIC_EVENTS[`${h.month}-${h.day}`];
              const isToday = d.toDateString() === today.toDateString();
              const isPicked = d.toDateString() === picked.toDateString();
              return (
                <button key={i} onClick={() => setPicked(d)} title={ev}
                  className={cn("rounded-lg p-1 min-h-14 flex flex-col items-center justify-center text-sm transition-colors border",
                    isToday ? "bg-emerald-600 text-white border-emerald-600" : isPicked ? "bg-emerald-100 border-emerald-400" : ev ? "bg-amber-50 border-amber-200" : "bg-emerald-50/40 border-transparent hover:bg-emerald-100")}>
                  <span className="font-semibold">{d.getDate()}</span>
                  <span className={cn("text-[10px]", isToday ? "text-emerald-100" : "text-emerald-700")}>{h.day}</span>
                  {ev && <span className="h-1 w-1 rounded-full bg-amber-500 mt-0.5" />}
                </button>
              );
            })}
          </div>
          <div className="mt-4 rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-sm">
            <p className="font-semibold text-emerald-900">{DAY_NAMES[picked.getDay()]}, {picked.getDate()} {MASEHI_MONTHS[picked.getMonth()]} {picked.getFullYear()}</p>
            <p className="text-emerald-700">{pickedH.day} {pickedH.monthName} {pickedH.year} H {ISLAMIC_EVENTS[`${pickedH.month}-${pickedH.day}`] ? `· ${ISLAMIC_EVENTS[`${pickedH.month}-${pickedH.day}`]}` : ""}</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border-slate-200">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Hari Besar Islam Bulan Ini</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {monthEvents.length === 0 && <p className="text-sm text-slate-500">Tidak ada hari besar pada bulan ini.</p>}
            {monthEvents.map(({ d, h }) => (
              <div key={d.toISOString()} className="flex justify-between text-sm border-b border-slate-100 pb-1.5">
                <span className="font-medium text-slate-800">{ISLAMIC_EVENTS[`${h.month}-${h.day}`]}</span>
                <span className="text-slate-500">{d.getDate()} {MASEHI_MONTHS[d.getMonth()].slice(0, 3)} · {h.day} {HIJRI_MONTHS[h.month - 1]}</span>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card className="border-slate-200">
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><ArrowRightLeft className="h-4 w-4 text-emerald-600" /> Konversi Masehi → Hijriyah</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <input type="date" value={convertInput} onChange={(e) => setConvertInput(e.target.value)} className={inputClass} />
            {conv && <p className="text-lg font-bold text-emerald-800">{conv.day} {conv.monthName} {conv.year} H</p>}
          </CardContent>
        </Card>
      </div>
      <CategoryArticles category="Kalender" />
    </div>
  );
}
