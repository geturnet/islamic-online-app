import { useEffect, useState } from "react";
import { Download, PenTool, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { CALLIGRAPHY_FONTS, PRESET_TEXTS, ensureFont, renderCalligraphyPNG } from "@/lib/calligraphy";
import { PageHeader, inputClass, CategoryArticles } from "./_shared";

const THEMES = [
  { name: "Emas", color: "#b8860b", bg: "#fffbeb" },
  { name: "Zamrud", color: "#065f46", bg: "#ecfdf5" },
  { name: "Malam", color: "#fde68a", bg: "#022c22" },
  { name: "Klasik", color: "#1e293b", bg: "#ffffff" },
  { name: "Marun", color: "#7f1d1d", bg: "#fef2f2" },
];

export default function CalligraphyPage() {
  const [text, setText] = useState(PRESET_TEXTS[0].ar);
  const [font, setFont] = useState(CALLIGRAPHY_FONTS[0].id);
  const [color, setColor] = useState(THEMES[0].color);
  const [bg, setBg] = useState(THEMES[0].bg);
  const [size, setSize] = useState(64);
  const [frame, setFrame] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => { CALLIGRAPHY_FONTS.forEach((f) => ensureFont(f.id)); }, []);

  const download = async () => {
    setBusy(true);
    const url = await renderCalligraphyPNG({ text, font, color, bg, size, frame });
    const a = document.createElement("a");
    a.href = url;
    a.download = `kaligrafi-${font.replace(/\s+/g, "-").toLowerCase()}.png`;
    a.click();
    setBusy(false);
  };

  return (
    <div className="space-y-5">
      <PageHeader icon={PenTool} title="Arabic Calligraphy Generator" desc="Buat kaligrafi Arab dengan 8 gaya khat, atur warna, lalu unduh sebagai gambar PNG" />

      <Card className="border-emerald-200 overflow-hidden">
        <div className="relative flex items-center justify-center p-8 min-h-64 transition-colors" style={{ background: bg }}>
          {frame && <div className="absolute inset-3 border-4 rounded" style={{ borderColor: color }}><div className="absolute inset-2 border rounded" style={{ borderColor: color }} /></div>}
          <p dir="rtl" className="text-center leading-[1.8] whitespace-pre-line relative" style={{ fontFamily: `"${font}", Amiri, serif`, color, fontSize: size }}>{text || "…"}</p>
        </div>
        <CardContent className="p-4 space-y-4">
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={2} dir="rtl" className={cn(inputClass, "text-2xl font-serif text-right")} placeholder="اكتب النص العربي هنا" />
          <div className="flex flex-wrap gap-1.5">
            {PRESET_TEXTS.map((p) => (
              <button key={p.latin} onClick={() => setText(p.ar)} className="text-xs px-2.5 py-1 rounded-full border border-emerald-200 text-emerald-700 hover:bg-emerald-50">{p.latin}</button>
            ))}
          </div>

          <div>
            <p className="text-xs font-medium text-slate-600 mb-2">Gaya Khat</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {CALLIGRAPHY_FONTS.map((f) => (
                <button key={f.id} onClick={() => setFont(f.id)} className={cn("rounded-xl border p-2 text-center transition-all", font === f.id ? "border-emerald-500 bg-emerald-50 shadow-sm" : "border-slate-200 hover:border-emerald-300")}>
                  <span className="block text-2xl" style={{ fontFamily: `"${f.id}"` }} dir="rtl">الحكمة</span>
                  <span className="block text-xs font-semibold text-slate-800">{f.style}</span>
                  <span className="block text-[10px] text-slate-500">{f.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <p className="text-xs font-medium text-slate-600 mb-2">Tema warna</p>
              <div className="flex flex-wrap gap-2">
                {THEMES.map((t) => (
                  <button key={t.name} onClick={() => { setColor(t.color); setBg(t.bg); }} className={cn("h-9 px-3 rounded-lg border text-xs font-semibold", color === t.color && bg === t.bg && "ring-2 ring-emerald-500")} style={{ background: t.bg, color: t.color }}>{t.name}</button>
                ))}
              </div>
              <div className="flex gap-3 mt-2 text-xs text-slate-600">
                <label className="flex items-center gap-1">Teks <input type="color" value={color} onChange={(e) => setColor(e.target.value)} /></label>
                <label className="flex items-center gap-1">Latar <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} /></label>
                <label className="flex items-center gap-1"><input type="checkbox" checked={frame} onChange={(e) => setFrame(e.target.checked)} /> Bingkai</label>
              </div>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-600 mb-2">Ukuran: {size}px</p>
              <input type="range" min={28} max={120} value={size} onChange={(e) => setSize(Number(e.target.value))} className="w-full" />
            </div>
          </div>

          <Button onClick={download} disabled={busy || !text} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            {busy ? <ImageIcon className="h-4 w-4 mr-2 animate-pulse" /> : <Download className="h-4 w-4 mr-2" />} Unduh PNG (1600×900)
          </Button>
        </CardContent>
      </Card>
      <CategoryArticles category="Arabic Calligraphy" />
    </div>
  );
}
