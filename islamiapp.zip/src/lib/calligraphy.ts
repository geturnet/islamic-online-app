/** Gaya kaligrafi → font Arab Google Fonts (dimuat di index.html). */
export const CALLIGRAPHY_FONTS = [
  { id: "Amiri", style: "Naskh", desc: "Gaya klasik mushaf Al-Qur'an" },
  { id: "Scheherazade New", style: "Naskh Modern", desc: "Naskh yang jelas & elegan" },
  { id: "Reem Kufi", style: "Kufi", desc: "Gaya geometris untuk desain modern" },
  { id: "Aref Ruqaa", style: "Riq'ah", desc: "Gaya tulisan tangan sehari-hari" },
  { id: "Noto Nastaliq Urdu", style: "Farisi (Nasta'liq)", desc: "Gaya Persia yang mengalir" },
  { id: "Rakkas", style: "Dekoratif (Tsuluts)", desc: "Tebal & dekoratif untuk judul" },
  { id: "Lalezar", style: "Display", desc: "Tegas untuk poster dan banner" },
  { id: "Lateef", style: "Sindhi Naskh", desc: "Ringan untuk teks panjang" },
];

export const PRESET_TEXTS = [
  { ar: "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ", latin: "Bismillah" },
  { ar: "اَلْحَمْدُ لِلّٰهِ", latin: "Alhamdulillah" },
  { ar: "سُبْحَانَ اللّٰهِ", latin: "Subhanallah" },
  { ar: "اَللّٰهُ أَكْبَرُ", latin: "Allahu Akbar" },
  { ar: "لَا إِلٰهَ إِلَّا اللّٰهُ", latin: "La ilaha illallah" },
  { ar: "مُحَمَّدٌ رَسُوْلُ اللّٰهِ", latin: "Muhammad Rasulullah" },
  { ar: "مَا شَاءَ اللّٰهُ", latin: "Masya Allah" },
  { ar: "اَلْحِكْمَةُ", latin: "Al-Hikmah" },
];

export async function ensureFont(font: string, size = 64) {
  try { await document.fonts.load(`${size}px "${font}"`, "بسم"); } catch { /* abaikan */ }
}

/** Render teks Arab ke canvas dan kembalikan data PNG. */
export async function renderCalligraphyPNG(opts: { text: string; font: string; color: string; bg: string; size: number; width?: number; height?: number; transparent?: boolean; frame?: boolean }) {
  const { text, font, color, bg, size, width = 1600, height = 900, transparent = false, frame = false } = opts;
  await ensureFont(font, size);
  const c = document.createElement("canvas");
  c.width = width;
  c.height = height;
  const ctx = c.getContext("2d")!;
  if (!transparent) { ctx.fillStyle = bg; ctx.fillRect(0, 0, width, height); }
  if (frame) {
    ctx.strokeStyle = color; ctx.lineWidth = 6; ctx.strokeRect(30, 30, width - 60, height - 60);
    ctx.lineWidth = 2; ctx.strokeRect(48, 48, width - 96, height - 96);
  }
  ctx.fillStyle = color;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.direction = "rtl";
  const lines = text.split("\n");
  let fontSize = size * 2;
  ctx.font = `${fontSize}px "${font}"`;
  const maxW = width - 160;
  const widest = Math.max(...lines.map((l) => ctx.measureText(l).width));
  if (widest > maxW) { fontSize = Math.floor(fontSize * (maxW / widest)); ctx.font = `${fontSize}px "${font}"`; }
  const lh = fontSize * 1.6;
  lines.forEach((l, i) => ctx.fillText(l, width / 2, height / 2 + (i - (lines.length - 1) / 2) * lh));
  return c.toDataURL("image/png");
}

export function buildSVG(opts: { text: string; font: string; color: string; bg: string; size: number; transparent?: boolean }) {
  const { text, font, color, bg, size, transparent } = opts;
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const lines = text.split("\n");
  const lh = size * 1.6;
  const h = Math.max(300, lines.length * lh + 120);
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="${h}" viewBox="0 0 1600 ${h}">
  <title>ALHIKMAH Arabic - ${esc(font)}</title>
  ${transparent ? "" : `<rect width="100%" height="100%" fill="${bg}"/>`}
  <g font-family="${esc(font)}, Amiri, serif" font-size="${size}" fill="${color}" text-anchor="middle" direction="rtl">
${lines.map((l, i) => `    <text x="800" y="${h / 2 + (i - (lines.length - 1) / 2) * lh}" dominant-baseline="middle">${esc(l)}</text>`).join("\n")}
  </g>
</svg>`;
}
