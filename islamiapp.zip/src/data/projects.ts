export type ProjectLink = { name: string; description: string; url: string };

/** Direktori proyek live yang di-host di awdevmyid.github.io. */
export const PROJECT_DIRECTORY: ProjectLink[] = [
  { name: "Aplikasi", description: "Collection of custom interactive web applications and utilities.", url: "https://awdevmyid.github.io/aplikasi/" },
  { name: "Calligraphy", description: "Arabic calligraphy and typography design tools and generators.", url: "https://awdevmyid.github.io/calligraphy/" },
  { name: "Code", description: "Programming snippets, templates, and code resources.", url: "https://awdevmyid.github.io/code/" },
  { name: "Collor", description: "Color palette generators, color picker, and design color tools.", url: "https://awdevmyid.github.io/collor/" },
  { name: "EQ", description: "Equalizer and sound tuning parameters / audio utilities.", url: "https://awdevmyid.github.io/eq/" },
  { name: "Finder", description: "Search utility and index finder tools for quick lookup.", url: "https://awdevmyid.github.io/finder/" },
  { name: "Img", description: "Image gallery, logos, icons, and visual assets storage.", url: "https://awdevmyid.github.io/img/" },
  { name: "Kodepost", description: "Indonesian postal code (Kode Pos) finder and regional lookup.", url: "https://awdevmyid.github.io/kodepost/" },
  { name: "Maps", description: "Interactive map integrations, geolocation, and mapping tools.", url: "https://awdevmyid.github.io/maps/" },
  { name: "QR", description: "QR Code generator and scanner web utility.", url: "https://awdevmyid.github.io/qr/" },
  { name: "Quran", description: "Digital Al-Quran reader, search, and audio recitation web app.", url: "https://awdevmyid.github.io/quran/" },
  { name: "SEO", description: "Search Engine Optimization analysis tools and meta tag generators.", url: "https://awdevmyid.github.io/seo/" },
  { name: "Source", description: "Open-source code templates and repository resource files.", url: "https://awdevmyid.github.io/source/" },
  { name: "Tools", description: "Multi-purpose utility web tools for daily productivity.", url: "https://awdevmyid.github.io/tools/" },
  { name: "Vidio", description: "Video showcase, cinematic clips, and video streaming directory.", url: "https://awdevmyid.github.io/vidio/" },
];
